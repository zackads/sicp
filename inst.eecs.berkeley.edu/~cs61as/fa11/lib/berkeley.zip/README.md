This directory contains the CS 61AS Racket library.
The primary file is `berkeley/main.rkt`.
`info.rkt` contains metadata.

You'll notice that `berkeley/main.rkt` is duplicated in this
directory. This is for compatability reasons and you MUST
remember to maintain sameness between these two files.

To build, go into the directory above and run `raco pkg create berkeley`.
This will generate a `berkeley.zip` and a corresponding checksum file.

